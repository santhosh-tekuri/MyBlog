package santhosh;

public class Manager extends Employee{
    public Manager(String name){
        super(name);
    }
}
