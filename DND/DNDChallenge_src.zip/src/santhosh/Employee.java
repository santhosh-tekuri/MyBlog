package santhosh;

public class Employee extends Person{
    public Employee(String name){
        super(name);
    }
}
